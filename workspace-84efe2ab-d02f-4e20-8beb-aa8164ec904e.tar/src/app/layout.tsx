import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://nexusstudio.co"),
  title: "Nexus — Digital systems studio",
  description:
    "Nexus is a senior studio that designs, engineers, and automates the digital systems behind compounding revenue growth. Book a 30-minute scoping call.",
  keywords: [
    "digital studio",
    "web design",
    "AI automation",
    "SEO",
    "Next.js development",
    "conversion optimization",
  ],
  authors: [{ name: "Nexus Studio" }],
  openGraph: {
    title: "Nexus — Scaling your business, engineered.",
    description:
      "We build automated systems and premium digital experiences that drive revenue. No fluff, just results.",
    url: "https://nexusstudio.co",
    siteName: "Nexus Studio",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "Nexus — Scaling your business, engineered.",
    description:
      "Automated systems and premium digital experiences that drive revenue.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-black text-zinc-100 selection:bg-violet-500/30`}
      >
        {children}
        <Toaster
          position="bottom-right"
          theme="dark"
          toastOptions={{
            style: {
              background: "rgba(10,10,11,0.9)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "#fafafa",
              backdropFilter: "blur(12px)",
            },
          }}
        />
      </body>
    </html>
  );
}
