import { Navbar } from "@/components/site/navbar";
import { Hero } from "@/components/site/hero";
import { Services } from "@/components/site/services";
import { Stats } from "@/components/site/stats";
import { Pricing } from "@/components/site/pricing";
import { CTA } from "@/components/site/cta";
import { Footer } from "@/components/site/footer";
import { BookingModal } from "@/components/site/booking-modal";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-black">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Services />
        <Stats />
        <Pricing />
        <CTA />
      </main>
      <Footer />
      <BookingModal />
    </div>
  );
}
