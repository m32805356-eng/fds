"use client";

import { Check, ArrowRight } from "lucide-react";
import { useBooking } from "@/lib/booking-store";
import { Container, Eyebrow, gradientButton, ghostButton } from "./primitives";
import { cn } from "@/lib/utils";

type Plan = {
  name: string;
  price: string;
  cadence: string;
  desc: string;
  features: string[];
  cta: string;
  featured?: boolean;
};

const PLANS: Plan[] = [
  {
    name: "Sprint",
    price: "$4,900",
    cadence: "/ month",
    desc: "For founders who need a senior partner on a single workstream.",
    features: [
      "1 active workstream",
      "Weekly sprint reviews",
      "Async support · 48h SLA",
      "Figma + Next.js delivery",
    ],
    cta: "Start with Sprint",
  },
  {
    name: "Growth",
    price: "$9,900",
    cadence: "/ month",
    desc: "Our most popular engagement for teams scaling past product-market fit.",
    features: [
      "3 active workstreams",
      "Biweekly strategy calls",
      "Priority support · 24h SLA",
      "Conversion experiments",
      "Live analytics dashboard",
    ],
    cta: "Choose Growth",
    featured: true,
  },
  {
    name: "Partner",
    price: "Custom",
    cadence: "",
    desc: "An embedded studio team for category leaders.",
    features: [
      "Unlimited workstreams",
      "Dedicated lead",
      "Slack connect access",
      "Roadmap ownership",
      "Quarterly business review",
    ],
    cta: "Talk to us",
  },
];

export function Pricing() {
  const openBooking = useBooking((s) => s.open);

  return (
    <section id="pricing" className="relative py-24 sm:py-32">
      <Container>
        <div className="max-w-2xl">
          <Eyebrow>Pricing</Eyebrow>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Engagements priced for outcomes, not hours.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-zinc-400">
            Fixed monthly retainers with a clear scope. Cancel anytime after the
            first 90 days — no lock-in, no surprise invoices.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-4 lg:grid-cols-3">
          {PLANS.map((p) => (
            <div
              key={p.name}
              className={cn(
                "relative flex h-full flex-col rounded-2xl p-7 backdrop-blur transition-colors duration-300",
                p.featured
                  ? "border border-violet-500/40 bg-white/[0.04] hover:border-violet-400/60 hover:shadow-[0_0_50px_-16px_rgba(139,92,246,0.55)]"
                  : "border border-white/10 bg-white/[0.025] hover:border-white/20",
              )}
            >
              {p.featured && (
                <span className="absolute -top-3 left-7 inline-flex items-center rounded-full bg-gradient-to-r from-violet-500 to-blue-500 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-white">
                  Most popular
                </span>
              )}

              <div className="flex items-baseline justify-between">
                <h3 className="text-base font-semibold text-white">{p.name}</h3>
              </div>

              <div className="mt-4 flex items-baseline gap-1">
                <span className="font-mono text-4xl font-semibold tracking-tight text-white">
                  {p.price}
                </span>
                {p.cadence && (
                  <span className="text-sm text-zinc-500">{p.cadence}</span>
                )}
              </div>

              <p className="mt-3 text-sm leading-relaxed text-zinc-400">
                {p.desc}
              </p>

              <ul className="mt-6 space-y-3 border-t border-white/10 pt-6">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-zinc-300">
                    <Check
                      className="mt-0.5 size-4 shrink-0 text-violet-400"
                      strokeWidth={2.5}
                    />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-auto pt-8">
                <button
                  onClick={() => openBooking(`pricing-${p.name.toLowerCase()}`)}
                  className={cn(
                    "w-full",
                    p.featured ? gradientButton : ghostButton,
                  )}
                >
                  {p.cta}
                  <ArrowRight className="size-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-8 text-center text-xs text-zinc-600">
          All plans include source files, documentation, and a 30-day post-launch
          support window.
        </p>
      </Container>
    </section>
  );
}
