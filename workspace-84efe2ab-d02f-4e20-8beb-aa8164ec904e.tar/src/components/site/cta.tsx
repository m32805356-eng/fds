"use client";

import { ArrowRight } from "lucide-react";
import { useBooking } from "@/lib/booking-store";
import { Container } from "./primitives";

export function CTA() {
  const openBooking = useBooking((s) => s.open);

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <Container>
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-violet-600 via-violet-600 to-blue-600 px-6 py-16 text-center sm:px-12 sm:py-20">
          {/* Texture + glow */}
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute inset-0 bg-grid opacity-[0.15]" />
            <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-white/20 blur-[100px]" />
            <div className="absolute -bottom-24 -right-10 h-72 w-72 rounded-full bg-blue-300/20 blur-[100px]" />
          </div>

          <div className="relative mx-auto max-w-2xl">
            <h2 className="text-balance text-3xl font-semibold leading-tight tracking-tight text-white sm:text-5xl">
              Ready to upgrade your digital presence?
            </h2>
            <p className="mx-auto mt-5 max-w-lg text-pretty text-base leading-relaxed text-white/80 sm:text-lg">
              Book a 30-minute scoping call. We&apos;ll send a fixed-scope
              proposal within 48 hours — no obligations, no sales theater.
            </p>

            <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <button
                onClick={() => openBooking("cta")}
                className="group inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-black px-7 text-sm font-semibold text-white transition-all hover:bg-zinc-900 active:scale-[0.98] sm:w-auto"
              >
                Book a Call
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
              </button>
              <a
                href="mailto:hello@nexusstudio.co"
                className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-full border border-white/30 bg-white/10 px-7 text-sm font-semibold text-white backdrop-blur transition-colors hover:bg-white/20 sm:w-auto"
              >
                hello@nexusstudio.co
              </a>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
