import { Container, Eyebrow } from "./primitives";

const STATS = [
  { value: "150+", label: "Clients served" },
  { value: "$2.4M", label: "Revenue generated" },
  { value: "98%", label: "Client retention" },
  { value: "4.9/5", label: "Avg. rating" },
];

export function Stats() {
  return (
    <section id="about" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-1/2 h-[300px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-700/[0.07] blur-[150px]" />
      </div>

      <Container>
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <Eyebrow>About Nexus</Eyebrow>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              A small studio with the throughput of a product team.
            </h2>
            <p className="mt-5 text-base leading-relaxed text-zinc-400">
              Nexus is a seven-person studio of designers, engineers, and growth
              operators. We partner with a limited number of founders at a time
              so the work stays senior end-to-end — no handoffs to juniors, no
              bloated retainers.
            </p>
          </div>

          <div className="lg:col-span-7">
            <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02] sm:grid-cols-4">
              {STATS.map((s) => (
                <div
                  key={s.label}
                  className="flex flex-col justify-between gap-3 bg-black/40 p-6"
                >
                  <dt className="font-mono text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                    {s.value}
                  </dt>
                  <dd className="text-xs font-medium uppercase tracking-wider text-zinc-500">
                    {s.label}
                  </dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-600">
              Figures reflect Q4 2024 across active engagements.
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}
