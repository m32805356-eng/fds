"use client";

import { ArrowUp, ArrowRight } from "lucide-react";
import { useBooking } from "@/lib/booking-store";
import { Container } from "./primitives";
import { cn } from "@/lib/utils";

const COLS = [
  {
    title: "Services",
    links: [
      { label: "Web Design", href: "#services" },
      { label: "AI Automation", href: "#services" },
      { label: "SEO", href: "#services" },
      { label: "Brand Systems", href: "#services" },
      { label: "Web Development", href: "#services" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "#about" },
      { label: "Pricing", href: "#pricing" },
      { label: "Contact", href: "#contact" },
      { label: "Careers", href: "mailto:careers@nexusstudio.co" },
    ],
  },
];

export function Footer() {
  const openBooking = useBooking((s) => s.open);

  return (
    <footer className="mt-auto border-t border-white/10 bg-black">
      <Container className="py-16">
        <div className="grid grid-cols-2 gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-2">
            <a
              href="#top"
              className="flex items-center gap-2 text-[17px] font-semibold tracking-tight text-white"
            >
              <span className="flex size-7 items-center justify-center rounded-md bg-gradient-to-br from-violet-500 to-blue-500">
                <span className="size-2 rounded-[2px] bg-white" />
              </span>
              Nexus
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-zinc-400">
              A senior digital systems studio. We design, build, and automate the
              infrastructure behind compounding revenue.
            </p>
            <button
              onClick={() => openBooking("footer")}
              className={cn(
                "group mt-6 inline-flex h-10 items-center justify-center gap-2 rounded-full bg-white/5 px-5 text-sm font-medium text-zinc-200 ring-1 ring-inset ring-white/10 transition-colors hover:bg-white/10",
              )}
            >
              Book a call
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </button>
          </div>

          {COLS.map((col) => (
            <div key={col.title}>
              <h3 className="font-mono text-[11px] font-medium uppercase tracking-[0.2em] text-zinc-500">
                {col.title}
              </h3>
              <ul className="mt-4 space-y-3">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      className="text-sm text-zinc-400 transition-colors hover:text-white"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t border-white/10 pt-8 sm:flex-row sm:items-center">
          <p className="text-xs text-zinc-500">
            © 2025 Nexus Studio. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a
              href="mailto:hello@nexusstudio.co"
              className="text-xs text-zinc-500 transition-colors hover:text-white"
            >
              hello@nexusstudio.co
            </a>
            <a
              href="#top"
              className="inline-flex items-center gap-1.5 text-xs text-zinc-500 transition-colors hover:text-white"
            >
              Back to top
              <ArrowUp className="size-3.5" />
            </a>
          </div>
        </div>
      </Container>
    </footer>
  );
}
