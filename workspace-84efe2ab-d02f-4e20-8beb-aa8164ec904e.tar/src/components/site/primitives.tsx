import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function Container({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mx-auto w-full max-w-6xl px-5 sm:px-8", className)}>
      {children}
    </div>
  );
}

export function Eyebrow({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-zinc-500",
        className,
      )}
    >
      <span className="h-1 w-1 rounded-full bg-gradient-to-r from-violet-400 to-blue-400" />
      {children}
    </div>
  );
}

// Shared button class strings — one pill radius system across the whole site.
export const gradientButton =
  "group inline-flex h-11 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-blue-500 px-6 text-sm font-semibold text-white transition-all hover:from-violet-400 hover:to-blue-400 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500/50 focus-visible:ring-offset-2 focus-visible:ring-offset-black disabled:opacity-50";

export const ghostButton =
  "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-white/15 bg-white/[0.02] px-6 text-sm font-semibold text-zinc-200 transition-colors hover:border-white/30 hover:bg-white/[0.06] active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/30 focus-visible:ring-offset-2 focus-visible:ring-offset-black";
