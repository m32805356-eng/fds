"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, ArrowDown } from "lucide-react";
import { useBooking } from "@/lib/booking-store";
import { Container, Eyebrow, gradientButton, ghostButton } from "./primitives";
import { cn } from "@/lib/utils";

const CLIENTS = ["VANTA", "LUMEN", "ORBIT", "HELIX"];

export function Hero() {
  const openBooking = useBooking((s) => s.open);
  const reduce = useReducedMotion();

  const container = {
    hidden: {},
    show: {
      transition: { staggerChildren: 0.08, delayChildren: 0.05 },
    },
  };
  const item = {
    hidden: { opacity: 0, y: reduce ? 0 : 14 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const } },
  };

  return (
    <section id="top" className="relative overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-28">
      {/* Background layers — restrained, one accent glow + faint grid */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-grid [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_30%,transparent_75%)]" />
        <div className="absolute left-1/2 top-[-10%] h-[460px] w-[680px] -translate-x-1/2 rounded-full bg-violet-600/20 blur-[140px]" />
        <div className="absolute right-[10%] top-[20%] h-[280px] w-[280px] rounded-full bg-blue-600/10 blur-[120px]" />
      </div>

      <Container>
        <motion.div variants={container} initial="hidden" animate="show" className="mx-auto max-w-3xl text-center">
          <motion.div variants={item} className="flex justify-center">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 backdrop-blur">
              <span className="relative flex size-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                <span className="relative inline-flex size-1.5 rounded-full bg-emerald-400" />
              </span>
              <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-400">
                Taking on 2 new partners · Q1 2025
              </span>
            </div>
          </motion.div>

          <motion.h1
            variants={item}
            className="mt-7 text-balance text-4xl font-semibold leading-[1.05] tracking-tight text-white sm:text-6xl"
          >
            Scaling your business,{" "}
            <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-blue-400 bg-clip-text text-transparent">
              engineered.
            </span>
          </motion.h1>

          <motion.p
            variants={item}
            className="mx-auto mt-6 max-w-xl text-pretty text-base leading-relaxed text-zinc-400 sm:text-lg"
          >
            We build automated systems and premium digital experiences that drive
            revenue. No fluff, just results.
          </motion.p>

          <motion.div
            variants={item}
            className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            <button onClick={() => openBooking("hero")} className={cn(gradientButton, "w-full sm:w-auto")}>
              Book a Call
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </button>
            <a href="#services" className={cn(ghostButton, "w-full sm:w-auto")}>
              View Work
              <ArrowDown className="size-4" />
            </a>
          </motion.div>
        </motion.div>

        {/* Trusted by */}
        <motion.div
          variants={item}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.5, duration: 0.6 }}
          className="mx-auto mt-20 max-w-3xl"
        >
          <p className="text-center font-mono text-[11px] uppercase tracking-[0.22em] text-zinc-600">
            Trusted by teams shipping at scale
          </p>
          <div className="mt-6 grid grid-cols-2 items-center gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.02] sm:grid-cols-4">
            {CLIENTS.map((c) => (
              <div
                key={c}
                className="flex h-16 items-center justify-center border-white/[0.04] bg-transparent px-4 text-center font-mono text-sm font-semibold tracking-[0.2em] text-zinc-600 transition-colors hover:text-zinc-400 sm:border-l:first:border-l-0"
              >
                {c}
              </div>
            ))}
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
