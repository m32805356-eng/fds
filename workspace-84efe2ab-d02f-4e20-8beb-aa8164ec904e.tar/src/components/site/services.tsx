import {
  LayoutTemplate,
  Workflow,
  Search,
  Aperture,
  Code2,
  Gauge,
  type LucideIcon,
} from "lucide-react";
import { Container, Eyebrow } from "./primitives";

type Service = {
  icon: LucideIcon;
  title: string;
  desc: string;
};

const SERVICES: Service[] = [
  {
    icon: LayoutTemplate,
    title: "Web Design",
    desc: "Conversion-first interfaces designed in Figma and shipped pixel-perfect. Every screen is built around how your customers actually buy.",
  },
  {
    icon: Workflow,
    title: "AI Automation",
    desc: "We connect your tools and eliminate manual work with reliable, auditable workflows. Less context-switching, more output per headcount.",
  },
  {
    icon: Search,
    title: "SEO",
    desc: "Technical, on-page, and content programs that compound month over month. We target purchase intent, not vanity keywords.",
  },
  {
    icon: Aperture,
    title: "Brand Systems",
    desc: "Identity, voice, and design tokens packaged into a system your team can actually use. Consistent across every touchpoint without slowing you down.",
  },
  {
    icon: Code2,
    title: "Web Development",
    desc: "Next.js frontends engineered for speed, accessibility, and scale. Shipped with CI, analytics, and observability from day one.",
  },
  {
    icon: Gauge,
    title: "Conversion Optimization",
    desc: "We instrument every step of the funnel and run continuous experiments. Win rates compound when the learning loop is tight.",
  },
];

export function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32">
      <Container>
        <div className="max-w-2xl">
          <Eyebrow>What we do</Eyebrow>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Capabilities built for compounding growth.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-zinc-400">
            Six disciplines, one senior team. We slot into your roadmap and ship
            work that moves a metric — not work that looks busy.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:auto-rows-fr">
          {SERVICES.map((s) => (
            <article
              key={s.title}
              className="group relative flex flex-col rounded-2xl border border-white/10 bg-white/[0.025] p-6 backdrop-blur transition-colors duration-300 hover:border-violet-500/40 hover:shadow-[0_0_40px_-14px_rgba(139,92,246,0.5)]"
            >
              <div className="flex size-10 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-zinc-200 transition-colors duration-300 group-hover:border-violet-500/40 group-hover:text-violet-300">
                <s.icon className="size-5" strokeWidth={1.75} />
              </div>
              <h3 className="mt-5 text-base font-semibold tracking-tight text-white">
                {s.title}
              </h3>
              <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">
                {s.desc}
              </p>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
