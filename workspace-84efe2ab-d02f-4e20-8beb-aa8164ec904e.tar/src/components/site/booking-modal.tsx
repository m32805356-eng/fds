"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useBooking } from "@/lib/booking-store";
import { toast } from "sonner";
import { Check, Loader2, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

type Status = "idle" | "loading" | "success";

const SCOPES = [
  "Web design / redesign",
  "AI automation",
  "SEO & content",
  "Web development",
  "Conversion optimization",
  "Not sure yet",
];

export function BookingModal() {
  const { isOpen, close, source } = useBooking();
  const [status, setStatus] = useState<Status>("idle");
  const [form, setForm] = useState({
    name: "",
    email: "",
    company: "",
    scope: SCOPES[0],
  });
  const [touched, setTouched] = useState(false);

  // Reset whenever the modal is closed.
  useEffect(() => {
    if (!isOpen) {
      const t = setTimeout(() => {
        setStatus("idle");
        setTouched(false);
      }, 200);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
  const nameValid = form.name.trim().length >= 2;
  const canSubmit = nameValid && emailValid && status !== "loading";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setTouched(true);
    if (!canSubmit) return;

    setStatus("loading");
    // Simulated async submission to a backend endpoint.
    await new Promise((r) => setTimeout(r, 1400));
    setStatus("success");
    toast.success("Request received", {
      description: "We'll reply within one business day.",
    });
  }

  return (
    <Dialog open={isOpen} onOpenChange={(o) => !o && close()}>
      <DialogContent className="sm:max-w-md rounded-2xl border-white/10 bg-zinc-950/90 p-0 overflow-hidden backdrop-blur-xl">
        {/* Top accent line */}
        <div className="h-px w-full bg-gradient-to-r from-transparent via-violet-500/60 to-transparent" />

        {status === "success" ? (
          <div className="px-7 py-10 text-center">
            <div className="mx-auto mb-5 flex size-12 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-blue-500">
              <Check className="size-6 text-white" strokeWidth={2.5} />
            </div>
            <DialogTitle className="text-xl font-semibold tracking-tight text-white">
              You&apos;re on the list
            </DialogTitle>
            <DialogDescription className="mt-2 text-sm text-zinc-400">
              Thanks, {form.name.split(" ")[0] || "there"}. A senior partner will
              reach out within one business day to schedule your scoping call.
            </DialogDescription>
            <button
              onClick={close}
              className="mt-6 inline-flex h-10 items-center justify-center rounded-full border border-white/10 bg-white/5 px-5 text-sm font-medium text-zinc-200 transition-colors hover:bg-white/10"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="px-7 py-7">
            <DialogTitle className="text-xl font-semibold tracking-tight text-white">
              Book a scoping call
            </DialogTitle>
            <DialogDescription className="mt-1.5 text-sm text-zinc-400">
              30 minutes. We&apos;ll send a fixed-scope proposal within 48 hours.
            </DialogDescription>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="bk-name" className="text-xs font-medium text-zinc-300">
                  Full name
                </Label>
                <Input
                  id="bk-name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Jordan Reyes"
                  className="h-10 rounded-lg border-white/10 bg-white/5 text-zinc-100 placeholder:text-zinc-600 focus-visible:border-violet-500/60 focus-visible:ring-violet-500/20"
                />
                {touched && !nameValid && (
                  <p className="text-xs text-rose-400">Please enter your name.</p>
                )}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="bk-email" className="text-xs font-medium text-zinc-300">
                  Work email
                </Label>
                <Input
                  id="bk-email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="jordan@company.com"
                  className="h-10 rounded-lg border-white/10 bg-white/5 text-zinc-100 placeholder:text-zinc-600 focus-visible:border-violet-500/60 focus-visible:ring-violet-500/20"
                />
                {touched && !emailValid && (
                  <p className="text-xs text-rose-400">Enter a valid email address.</p>
                )}
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="bk-company" className="text-xs font-medium text-zinc-300">
                    Company <span className="text-zinc-600">(optional)</span>
                  </Label>
                  <Input
                    id="bk-company"
                    value={form.company}
                    onChange={(e) => setForm({ ...form, company: e.target.value })}
                    placeholder="Acme Inc."
                    className="h-10 rounded-lg border-white/10 bg-white/5 text-zinc-100 placeholder:text-zinc-600 focus-visible:border-violet-500/60 focus-visible:ring-violet-500/20"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="bk-scope" className="text-xs font-medium text-zinc-300">
                    Focus area
                  </Label>
                  <select
                    id="bk-scope"
                    value={form.scope}
                    onChange={(e) => setForm({ ...form, scope: e.target.value })}
                    className="h-10 w-full rounded-lg border border-white/10 bg-white/5 px-3 text-sm text-zinc-100 outline-none transition-[box-shadow] focus-visible:border-violet-500/60 focus-visible:ring-[3px] focus-visible:ring-violet-500/20"
                  >
                    {SCOPES.map((s) => (
                      <option key={s} value={s} className="bg-zinc-950 text-zinc-100">
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={!canSubmit}
                className={cn(
                  "group mt-2 inline-flex h-11 w-full items-center justify-center gap-2 rounded-full text-sm font-semibold text-white transition-all",
                  "bg-gradient-to-r from-violet-500 to-blue-500 hover:from-violet-400 hover:to-blue-400",
                  "disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:from-violet-500 disabled:hover:to-blue-500",
                )}
              >
                {status === "loading" ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Sending request…
                  </>
                ) : (
                  <>
                    Request my call
                    <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
                  </>
                )}
              </button>

              <p className="text-center text-[11px] text-zinc-600">
                No spam. Source:{" "}
                <span className="font-mono text-zinc-500">{source}</span>
              </p>
            </form>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
