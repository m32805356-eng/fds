import { create } from "zustand";

interface BookingState {
  isOpen: boolean;
  source: string;
  open: (source?: string) => void;
  close: () => void;
}

export const useBooking = create<BookingState>((set) => ({
  isOpen: false,
  source: "hero",
  open: (source = "hero") => set({ isOpen: true, source }),
  close: () => set({ isOpen: false }),
}));
